package com.cg.banking.services;

public interface BankingServices {

}
