package com.cg.banking.controllers;

public class URIController {

}
