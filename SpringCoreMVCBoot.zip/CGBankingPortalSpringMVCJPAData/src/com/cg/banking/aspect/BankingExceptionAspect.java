package com.cg.banking.aspect;

public class BankingExceptionAspect {

}
