package com.cg.project.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.project.beans.Employee;

public class MainClass {
	public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("ProjectBeans.xml");
	Employee employee1 =(Employee)context.getBean("employee");
	Employee employee2 =(Employee)context.getBean("employee");
   if(employee1==employee2)
	System.out.println("Same reference");
   else
		System.out.println("No Same reference");
   if(employee1.equals(employee2))
		System.out.println("Same data");
   else
      		System.out.println("Not Same data");
	}
}