package com.cg.payroll.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailNotFoundException;
import com.cg.payroll.services.payrollServices;
@Controller
public class PayrollServicesController {
	@Autowired
	payrollServices payrollServices1;
	@RequestMapping("/registerAssociate")
	public ModelAndView registerAssociate(@Valid@ModelAttribute Associate associate,BindingResult result) {
		if(result.hasErrors())return new ModelAndView("registrationPage");
		associate=payrollServices1.acceptAssociateDetails(associate);
		return new ModelAndView("registrationSuccessPage","associate",associate);
	}
	@RequestMapping("/associateDetails")
	public ModelAndView getAssociateDetails(@RequestParam int associateId)throws AssociateDetailNotFoundException {
		Associate associate=payrollServices1.getAssociateDetails(associateId);
		return new ModelAndView("findAssociateDetailsPage","associate",associate);
	}
} 