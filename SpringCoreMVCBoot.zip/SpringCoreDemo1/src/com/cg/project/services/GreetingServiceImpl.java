package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingServiceImpl implements GreetingServices{

	
	public void greetUser(String name) {
	 System.out.println("hello "+name);
		
	}

}
